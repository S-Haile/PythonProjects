#Samson Haile
#Sorts

#Sorts a list using the Insertion Sort method
def insertionSort(inList):
    for place in range(1, len(inList)):
        temp = inList[place]
        i = place
        #if the item in the previous spot is greater than the current item
        #we swap them
        while i > 0 and inList[i - 1] > temp:
            inList[i] = inList[i-1]
            i = i - 1
        inList[i] = temp

#Sorts a list using the Bubble Sort method
def bubbleSort(inList):
    for num in range(len(inList)-1,0,-1):
        for i in range(num):
            #If the item in the current position is less than the item in the next position
            #we swap them
            if inList[i]>inList[i+1]:
                temp = inList[i]
                inList[i] = inList[i+1]
                inList[i+1] = temp
                
#Recursive function to sort via the Quick Sort method
def quickSortRec(inList, first, last):
    if last  - first < 5:
        insertionSortPartialList(inList,first,last)
        return
    
    #code to calculate the pivot
    mid = (first + last) // 2
    if inList[first] > inList[last]:
        inList[first],inList[last] = inList[last],inList[first]
    if inList[first] > inList[mid]:
        inList[first],inList[mid] = inList[mid],inList[first]
    if inList[mid] > inList[last]:
        inList[mid],inList[last] = inList[last],inList[mid]
        
    pivot = inList[mid]
    inList[last-1],inList[mid] = inList[mid],inList[last-1]
    left = first + 1
    right = last - 2
    done = False
    while not done:
        while inList[left] < pivot:
            left += 1
        while inList[right] > pivot:
            right -= 1
        if right > left:
            inList[left], inList[right] = inList[right], inList[left]
            left += 1
            right -= 1
        else:
            done = True
    
    inList[left], inList[last-1] = inList[last - 1],inList[left]
    quickSortRec(inList, first, left -1)
    quickSortRec(inList, left + 1, last)
    
#function that is used to call the recursive Quick Sort method
#and gives it a new last argument
def quickSort(inList):
    last = len(inList) - 1
    quickSortRec(inList, 0, last)

#Small insertion sort method used in Quick Sort to sort las portion of list
def insertionSortPartialList(inList, first, last):
    for place in range(first + 1, last + 1):
        temp = inList[place]
        i = place
        #if the item in the previous spot is greater than the current item
        #we swap them
        while i > 0 and inList[i - 1] > temp:
            inList[i] = inList[i-1]
            i = i - 1
        inList[i] = temp

#function that sorts via the Shell Sort method
def shellSort(inList):
    size = len(inList)
    gap = size // 2
    while gap > 0:
        for i in range (gap, size):
            temp = inList[i]
            j = i
            while j >= gap and temp < inList[j - gap]:
                inList[j] = inList[j - gap]
                j -= gap
            inList[j] = temp
        if gap == 2:
            gap = 1
        else:
            gap = int(gap/2.2)

#Sorts and merges the two lists
def merge(inList, first, mid, last):
    size = last - first + 1
    tempList = [0] * size
    first1 = first
    last1 = mid
    first2 = mid + 1
    last2 = last
    index = 0
    while first1 <= last1 and first2 <= last2:
        if inList[first1] < inList[first2]:
            tempList[index] = inList[first1]
            first1 += 1
        else:
            tempList[index] = inList[first2]
            first2 += 1

        index += 1
    while first1 <= last1:
        tempList[index] = inList[first1]
        first1 += 1
        index += 1
    while first2 <= last2:
        tempList[index] = inList[first2]
        first2 += 1
        index += 1
    for index in range(size):
        inList[first] = tempList[index]
        first += 1

#Uses the merge funciton to recursively sort a list      
def mergeSortRec(inList, first, last):
    if first < last:
        mid = (first + last) // 2
        mergeSortRec(inList, first, mid)
        mergeSortRec(inList, mid + 1, last)
        merge(inList, first, mid, last)

#function that is used to call the recursive Merge Sort method
#and gives it a new last argument      
def mergeSort(inList):
    last = len(inList) - 1
    mergeSortRec(inList, 0, last)

#merge function for iterativeMergeSort
def iterativemerge(inList, left, mid, right):
    copy_inList = []
    i, j = left, mid + 1
    ind = left
    while ind < right+1:
        #if left hand pos is passed the mid, copy from right side
        if i > mid:
            copy_inList.append(inList[j])
            j +=1
        #if mid is passed the right, copy from left side
        elif j > right:
            copy_inList.append(inList[i])
            i +=1
            
        #Check if right pos value is less than left one
        elif inList[j] < inList[i]:
            copy_inList.append(inList[j])
            j +=1
        else:
            copy_inList.append(inList[i])
            i +=1
        ind +=1
        
    ind=0
    for x in range(left,right+1):
        inList[x] = copy_inList[ind]
        ind += 1
        
#code that nonrecursively sorts via the Merge Sort method
def iterativeMergeSort(inList):
    factor = 2
    tempMid = 0
    
    while 1:
        index = 0
        left = 0
        right = len(inList) - (len(inList) % factor) - 1
        mid = (factor // 2) - 1
        while index < right:
            tempLeft = index
            tempRight = tempLeft + factor -1
            mid2 = (tempRight + tempLeft) // 2
            iterativemerge(inList, tempLeft, mid2, tempRight)
            index = (index + factor)
            
        #Chek if there is still something to merge
        if len(inList) % factor and tempMid !=0:

            
            #merge sub array to later be merged to the final array
            iterativemerge(inList, right +1, tempMid, len(inList)-1)
            
            #Update mid
            mid = right
            
        #Increase segement size
        factor = factor * 2
        tempMid = right
        #Final merge
        if factor > len(inList) :
            mid = right
            right = len(inList)-1
            iterativemerge(inList, 0, mid, right)
            break

