#Samson Haile
#Sorter
#Implements the sorting algorithms

import sys
import random
import sorts
import timeit

#function that takes input from the command line and sorts a list
#based on user input
def sort(sorttype = sys.argv[1], length = sys.argv[2], printit = ""):

    #checks if the user gave input for printit
    #if not, we set printit to be empty
    if len(sys.argv) == 4:
        printit = sys.argv[3]
    else:
        printit = ""

    #creates list of the user inputted length
    list1 = []
    i = 0
    x = int(length)
    while i < x:
        list1.append(random.randint(0,x))
        i = i + 1

    #prints unsorted list
    if printit.lower() == "print":
        print("Unsorted List:")
        print(list1)
        
        
    if sorttype.lower()== "bubblesort":
        print("Sorting with BubbleSort")  
        sorts.bubbleSort(list1)
                     
    if sorttype.lower() == "insertionsort":
        print("Sorting with InsertionSort")
        sorts.insertionSort(list1)

    if sorttype.lower() == "mergesort":
        print("Sorting with MergeSort")
        sorts.mergeSort(list1)
                     
    if sorttype.lower() == "iterativemergesort":
        print("Sorting with IterativeMergeSort")
        sorts.iterativeMergeSort(list1)
                     
    if sorttype.lower() == "shellsort":
        print("Sorting with ShellSort")
        sorts.shellSort(list1)
                     
    if sorttype.lower() == "quicksort":
        print("Sorting with QuickSort")
        sorts.quickSort(list1)

    #prints sorted list                     
    if printit.lower() == "print":
        print("Sorted List: ")
        print(list1)
    return ""

                     
print(sort())
