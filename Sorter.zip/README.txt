Program that has several different sorting algorithms for the user to use.
Also contains a report analyzing the effiency of them.