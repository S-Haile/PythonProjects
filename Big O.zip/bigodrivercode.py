import random
import timeit
import bigo
#Samson Haile
#10/21/17
#This is some simple code deisgned to time the different find methods
#of the module bigo

#x is the size of our list
x = 10
list1 = []
val = random.randint(0,x)
i = 0

#creates list of size x
while i < x:
    list1.append(random.randint(0,x))
    i = i+1
    
#creates a timer object which times the function
t = timeit.Timer(lambda:bigo.find1(list1, val))

#times the function 
duration = t.timeit()

print(duration)


