#Samson Haile
#10/22/17
#This is a module containing four different methods to find an item in a list

#This method does a linear search through the list to see if the value is present
def find1(list, val):
    length = len(list)
    i = 0
    while i < length:
        if val == list[i]:
            return True
        i = i + 1
    return False

#This first make sa copy of the given list, sorts it
#and then performs a binary search to see if the value is present
def find2(list, val):
    sortlist = []
    length = len(list)
    i = 0
    while i < length:
        sortlist.append(list[i])
        i = i + 1
    sortlist.sort()
    low = 0
    high = len(sortlist) - 1
    while low <= high:
        mid = (low + high) // 2
        if sortlist[mid] == val:
            return True
        elif val < sortlist[mid]:
            high = mid -1
        else:
            low = mid + 1
    return False

#This method uses Python's built-in 'in' function to see if the value is present in the list
def find3(list, val):
    if val in list:
        return True
    else:
        return False

#This method also performs a bianry search
#but it assumes the list is already sorted
def find4(list, val):
    low = 0
    high = len(list) - 1
    while low <= high:
        mid = (low + high) // 2
        if list[mid] == val:
            return True
        elif val < list[mid]:
            high = mid -1
        else:
            low = mid + 1
    return False



