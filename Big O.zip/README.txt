Looks at alogrithmic effiency by first analyzing other pieces of code, and then writing 4 ways
of finding an itemin a list, and then analyzing which is the most efficient.