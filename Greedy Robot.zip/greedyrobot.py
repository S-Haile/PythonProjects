#Samson Haile
#10/31/17
#The Greedy Robot Problem
#This function recursively calculates the the total number of shortest paths
#and prints each path and the total number
def NumPaths(x1,y1,x2,y2, passedpath = ""):
    path = passedpath
    result = 0
    #checks if the current position is equal to the treasure's location
    if x1 == x2 and y1 == y2:
        #increments everytime we hit the base case to count total number of paths
        result = result + 1
        print(path)

        #if path is empty, this means that given start position is equal to treasure position
        #if so, we return 0
        if path == "":
            return 0
        return result

    #Checks if starting position is southwest of the treasure position
    #if so we go northeast
    if x1 < x2 and y1 < y2:
        return NumPaths(x1+1,y1, x2, y2, path + "N") + NumPaths(x1, y1+1, x2, y2, path + "E")

    #Checks if starting position is south of the treasure position
    #if so we go north
    if x1 < x2 and y1 == y2:
        return NumPaths(x1+1,y1, x2, y2, path + "N")

    #Checks if starting position is west of the treasure position
    #if so we go east
    if x1 == x2 and y1 < y2:
        return NumPaths(x1, y1+1, x2, y2, path + "E")

    #Checks if starting position is southeast of the treasure position
    #if so we go northwest
    if x1 < x2 and y1 > y2:
        return NumPaths(x1+1,y1, x2, y2, path + "N") + NumPaths(x1, y1 - 1, x2, y2, path + "W")

    #Checks if starting position is northwest of the treasure position
    #if so we go southeast
    if x1 > x2 and y1 < y2:
        return NumPaths(x1-1,y1, x2, y2, path + "S") + NumPaths(x1, y1+1, x2, y2,path + "E")

    #Checks if starting position is northeast of the treasure position
    #if so we go southwest   
    if x1 > x2 and y1 > y2:
        return NumPaths(x1-1,y1, x2, y2,path + "S") + NumPaths(x1, y1 - 1, x2, y2,path + "W")

    #Checks if starting position is north of the treasure position
    #if so we go south
    if x1 > x2 and y1 == y2:
         return NumPaths(x1-1,y1, x2, y2, path + "S")

    #Checks if starting position is east of the treasure position
    #if so we go west   
    if x1 == x2 and y1 > y2:
        return NumPaths(x1, y1 - 1, x2, y2, path + "W")
    return 1


print("Number of Paths: " + str(NumPaths(-1,2,-3,0)))

