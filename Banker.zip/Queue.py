#Samson Haile
#12/13/207
#Queue

#Custom Queue class for JollyBanker

class Queue:
    
    def __init__(self):
        self.items = []

    def isEmpty(self):
        return self.items == []
    
    #adds an item to the queue (adds to front)
    def add(self,item):
        self.items.insert(0,item)

    #removes the last item from the queue (removes from front)
    def remove(self):
        return self.items.pop()

    def size(self):
        return len(self.items)

    #lets us look at the top of the queue
    def peek(self):
        return self.items[len(self.items)-1]

