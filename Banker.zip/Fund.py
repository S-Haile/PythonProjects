#Samson Haile
#12/13/2017
#Fund

#This class simulates the Fund as a part of the JollyBanker program
class Fund:

    def __init__(self, amount = 0):
        self.__amount = amount
        self.__history = []

    #gives the current amount of the fund
    def getAmount(self):
        return self.__amount

    #gives the history of the fund
    def getHistory(self):
        return self.__history

    #adds money to the account
    def deposit(self, amount):
        self.__amount = self.__amount + amount

    #removes money from the account
    def withdrawl(self, amount):
        self.__amount = self.__amount - amount
        if self.__amount < 0:
            self.__amount = 0
     
    #adds a transaction to the history list        
    def addHistory(self, item):
        self.__history.append(item)

    #prints the history of fund
    
    def printHistory(self):
        i = 0
        #removes any instance of "None" from the list
        self.__history[:] = [x for x in self.__history if x is not None]
        while i < len(self.__history):
            print(self.__history[i])
            i += 1
        print()
        return " "
