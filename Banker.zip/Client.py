#Samson Haile
#12/13/2017
#Client

#This class simulates the Client as a part of the JollyBanker program

import Transaction
from Fund import Fund
class Client:

    #Constructor. Creates a list of ten empty funds. Funds list has not been encapsulated
    #to give the other parts of the programs easier access
    def __init__ (self, idnumber, name = ""):
        self.__idnumber = idnumber
        self.__name = name
        self.funds = []
        i = 0
        while i < 10:
            fund = Fund()
            self.funds.append(fund)
            i += 1

    #returns the idNumber of the account
    def getidNumber(self):
        return self.__idnumber

    #reutrns name attached to account
    def getName(self):
        return self.__name

            
