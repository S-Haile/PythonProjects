#Samson Haile
#12/13/2017
#Tree

#Binary Search Tree and Node. The underlying data set on which our Bank in
#Jolly Banker is based on
class node:
    def __init__(self, key, value = None):
        self.__key = key
        self.__value = value
        self.__leftChild = None
        self.__rightChild = None

    def getLeftChild(self):
        return self.__leftChild
    
    def getRightChild(self):
        return self.__rightChild

    def setLeftChild(self, theNode):
        self.__leftChild = theNode
        return None

    def setRightChild(self, theNode):
        self.__rightChild = theNode
        return None

    def getValue(self):
        return self.__value
    
    def getKey(self):
        return self.__key

    def setValue(self, value):
        self.__value = value

    def setKey(self, key):
        self.__key = key

    def isLeaf(self):
        return self.getLeftChild() == None and self.getRightChild() == None

    
        
class BinarySearchTree:
    def __init__(self):
        self.__root = None
        self.__size = 0

    def getCount(self):
        return self.__size

    def isEmpty(self):
        return self.__size == 0

    #Searchs for an item in the tree
    #returns none if not present
    def findItem(self, key):
        currentNode = node(1)
        currentNode = self.__root
        while currentNode != None:
            if currentNode.getKey() == key:
                return currentNode.getValue()
            elif currentNode.getKey() > key:
                currentNode = currentNode.getLeftChild()
            else:
                currentNode = currentNode.getRightChild()
        return None

    def __getitem__(self, key):
        return self.findItem(key)

    #Adds item to the tree
    def insert(self, key, value):
        if self.isEmpty():
            self.__root = node(key, value)
            self.__size += 1
            return
        currentNode = node(1)
        currentNode = self.__root
        while currentNode != None:
            if currentNode.getKey() == key:
                currentNode.setValue(value)
                return
            elif currentNode.getKey() > key:
                if currentNode.getLeftChild() == None:
                    newNode = node(key, value)
                    currentNode.setLeftChild(newNode)
                    break
                else:
                    currentNode = currentNode.getLeftChild()
            else:
                if currentNode.getRightChild() == None:
                    newNode = node(key,value)
                    currentNode.setRightChild(newNode)
                    break
                else:
                    currentNode = currentNode.getRightChild()
        self.__size += 1
        return

    
    def __setitem__(self, key, data):
        self.insert(key, data)
        
    #Tranverses the tree In Order
    def inOrderTraversal(self, func):
        self.inOrderTraversalRec(self.__root, func)

    def inOrderTraversalRec(self, theNode, func):
        if theNode != None:
            self.inOrderTraversalRec(theNode.getLeftChild(), func)
            func(theNode.getKey(), theNode.getValue())
            self.inOrderTraversalRec(theNode.getRightChild(), func)

    #Tranverses the tree in Pre-Order
    def PreOrderTraversal(self):
        if self:
            print(self.getValue())
            preorder(self.getLeftChild())
            preorder(self.getRightChild())

    #Tranverses the tree in Post-Order
    def PostOrderTraversal(self):
        if self != None:
            postorder(self.getLeftChild())
            postorder(self.getRightChild())
            print(self.getValue())

    #removes an item from the tree
    #edits the tree accordingly
    def remove(self,key):
        if self.__root == None:
            return None
        if self.__root.getKey() == key:
            if self.__root.getLeftChild() == None:
                self.__root = self.__root.getRightChild()
            elif self.__root.getRightChild() == None:
                self.__root = self.__root.getLeftChild()
            else:
                replaceNode = self.__getAndRemoveRightSmall(self.__root)
                self.__root.setKey(replaceNode.getKey())
                self.__root.setValue(replaceNode.getValue)
        else:
            currentNode = node()
            currentNode = self.__root
            while currentNode != None:
                if currentNode.getLeftChild() and currentNode.getLeftChild().getKey() == key:
                    foundNode = currentNode.getLeftChild()
                    if foundNode.isLeaf():
                        currentNode.setLeftChild(None)
                    elif foundNode.getLeftChild() == None:
                        currentNode.setLeftChild(foundNode.getRightChild())
                    elif foundNode.getRightChild() == None:
                        currentNode.setLeftChild(foundNode.getLeftChild())
                    else:
                        replaceNode = self.getAndRemoveRightSmall(foundNode)
                        foundNode.setKey(replaceNode.getKey())
                        foundNode.setValue(replaceNode.getValue())
                    self.__size -= 1
                elif currentNode.getRightChild() and currentNode.getRightChild().getKey() == key:
                    pass
                    break
                elif currentNode.getKey() > key:
                    currentNode = currentNode.getLeftChild()
    
