#Samson Haile
#12/13/2017
#Client

#This class simulates the Bank as a part of the JollyBanker program. We only implement two methods from out BST
#Add and Get, since that is all we'll need for the program.
from Transaction import Transaction
import Client
import tree

class Bank:
    #Constructor. Creates a new instance of our Binary Search Tree
    #To store clients.
    def __init__(self):
        self.bank = tree.BinarySearchTree()

    #adds a client to the bank
    #with the Account Number acting as the key and the Client object being the value
    def addClient(self, idnumber, client):
        self.bank[idnumber] = client 

    #gets a client out of the bank given a account number    
    def getClient(self, idnumber):
        return self.bank.findItem(idnumber)


     

