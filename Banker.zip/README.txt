Program that emulates a bank.
Allows people to open accounts, deposit, withdraw, and transfer between funds and accounts.
Also allows the printing of account history.