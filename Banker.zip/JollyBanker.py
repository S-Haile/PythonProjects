#Samson Haile
#12/12/2017
#JollyBanker

#This class is the I/O of the JollyBanker assignment. It reads in the file, and stores all the transactions in a queue.
#It then parses through the queue, and executes the transactions

from Bank import Bank
from Transaction import Transaction 
import Queue
from Client import Client


class JollyBanker:

    #The constructor. Creates instances of the Bank and Queue, and reads in all the transactions
    def __init__(self):
        self.__bank = Bank()
        self.__q = Queue.Queue()
        self.__textfile = open('BankTransIn.txt','r')
        self.__line = self.__textfile.readline()

        #code that reads the file into the queue
        while self.__line != '':
            self.__trans = Transaction(self.__line)
            self.__q.add(self.__trans)
            self.__line = self.__textfile.readline().rstrip('\n')

    #This method executes the transactions
    #Has four 5 sections based on the 5 transaction types: Open, Deposit, Withdraw, Transfer, and History
    def executeTransactions(self):
        #iterates through the queue
        for n in self.__q.items[::-1]:
            y = n.getTransaction()

            #Code for opening an account
            if n.getTransactionType() == "O":

                #creates a client, getting the account number and name
                #and adds it to the bank
                client = Client(n.getAccNumber1(), n.getName())
                self.__bank.addClient(n.getAccNumber1(), client)

            #Checks if the transaction type is a deposit
            if n.getTransactionType() == "D":

                #code to handle if the amount being deposited is negative
                #creates an error and adds it to the history of the fund
                if n.getAmount() < 0:
                    error = "ERROR: Cannot deposit a negative amount"
                    client = self.__bank.getClient(n.getAccNumber1())
                    client.funds[n.getFundNumber1()].addHistory(error)

                #checks if the user is trying to deposit into an account that doesn't exist
                #if so, we create a new account with that account number and deposit into it
                if self.__bank.getClient(n.getAccNumber1()) == None:
                    client = Client(n.getAccNumber1(), n.getName())
                    self.__bank.addClient(n.getAccNumber1(), client)
                
                #gets the client, deposits, and adds the transaction to the history
                client = self.__bank.getClient(n.getAccNumber1())
                client.funds[int(n.getFundNumber1())].deposit(n.getAmount())
                client.funds[int(n.getFundNumber1())].addHistory(y)

            #Checks if the transaction type is a withdrawl
            if n.getTransactionType() == "W":
                client = self.__bank.getClient(n.getAccNumber1())
                y = (n.getAmount() - client.funds[int(n.getFundNumber1())].getAmount())
                #code to handle if the amount being wtihdrawn is negative
                #creates an error and adds it to the history of the fund
                if n.getAmount() < 0:
                    error = "ERROR: Cannot withdraw a negative amount"
                    client = self.__bank.getClient(n.getAccNumber1())
                    client.funds[n.getFundNumber1()].addHistory(error)

                #checks if the user is trying to withdraw from an account that doesn't exist
                #if so, we print an error 
                if self.__bank.getClient(n.getAccNumber1()) == None:
                    error = "ERROR: No Client exists with the given account number"
                    print(error)
                    
                #Checks for the special case in which we are trying to withdraw from the Money Market or Long-Term Bond account
                #and it must be covered by the Prime Money Market and Short-Term Bond account, respectively
                if n.getAmount() > client.funds[int(n.getFundNumber1())].getAmount() and (int(n.getFundNumber1()) == 0 or int(n.getFundNumber1()) == 2) and client.funds[int(n.getFundNumber1()) + 1].getAmount() >= y:
                    currentamount = client.funds[int(n.getFundNumber1())].getAmount()
                    
                    #Takes the amount we can from the inital fund
                    #and adds that transaction to the fund's history
                    client.funds[int(n.getFundNumber1())].withdrawl(n.getAmount())
                    trans = n.getTransactionType() + " " + n.getAccNumber1() + n.getFundNumber1() + " " + str(currentamount)
                    n.setAmount(n.getAmount() - currentamount) 
                    client.funds[int(n.getFundNumber1())].addHistory(trans)

                    #Takes the rest from the other fund
                    #and adds that transaction to the fund's history
                    client.funds[int(n.getFundNumber1()) + 1].withdrawl(n.getAmount())
                    trans2 = n.getTransactionType() + " " + n.getAccNumber1() + str(int(n.getFundNumber1()) + 1) + " " + str(n.getAmount())
                    client.funds[int(n.getFundNumber1()) + 1].addHistory(trans2)
                    
                #Checks for the special case in which we are trying to withdraw from the Prime Money Market or Short-Term Bond account
                #and it must be covered by the Money Market and Long-Term Bond account, respectively    
                elif n.getAmount() > client.funds[int(n.getFundNumber1())].getAmount() and (int(n.getFundNumber1()) == 1 or int(n.getFundNumber1()) == 3) and client.funds[int(n.getFundNumber1()) - 1].getAmount() > y:
                    currentamount = client.funds[int(n.getFundNumber1())].getAmount()
                    
                    #Takes the amount we can from the inital fund
                    #and adds that transaction to the fund's history
                    client.funds[int(n.getFundNumber1())].withdrawl(n.getAmount())
                    trans = n.getTransactionType() + " " + n.getAccNumber1() + n.getFundNumber1() + " " + str(currentamount)
                    n.setAmount(n.getAmount() - currentamount)  
                    client.funds[int(n.getFundNumber1())].addHistory(trans)

                    #Takes the rest from the other fund
                    #and adds that transaction to the fund's history
                    client.funds[int(n.getFundNumber1()) - 1].withdrawl(n.getAmount())
                    trans2 = n.getTransactionType() + " " + n.getAccNumber1() + str(int(n.getFundNumber1()) - 1) + " " + str(n.getAmount())
                    client.funds[int(n.getFundNumber1()) - 1].addHistory(trans2)

                #Checks for the standard case of overdrawing
                #We don't execute anything and that the transaction failed to the fund's history
                elif n.getAmount() > client.funds[int(n.getFundNumber1())].getAmount():
                    client.funds[int(n.getFundNumber1())].addHistory(n.getTransaction() + " (Failed)")

                #executes a standard withdrawl   
                else:
                     client.funds[int(n.getFundNumber1())].withdrawl(n.getAmount())
                     client.funds[int(n.getFundNumber1())].addHistory(n.getTransaction())
                     

                
            #Handles Transfers        
            if n.getTransactionType() == "T":
                client1 = self.__bank.getClient(n.getAccNumber1())
                client2 = self.__bank.getClient(n.getAccNumber2())

                #Handles if either of the accounts in the transfer aren't in the bank
                if client1 == None:
                    error = "ERROR Account Number: " + str(n.getAccNumber1()) + " does not exist in our bank."
                if client2 == None:
                    "ERROR Account Number: " + str(n.getAccNumber2()) + " does not exist in our bank."

                #Checks for the special case in which we are trying to transfer from the Money Market or Long-Term Bond account
                #and it must be covered by the Prime Money Market and Short-Term Bond account, respectively
                if n.getAmount() > client.funds[int(n.getFundNumber1())].getAmount() and (int(n.getFundNumber1()) == 0 or int(n.getFundNumber1()) == 2) and client.funds[int(n.getFundNumber1()) + 1].getAmount() >= n.getAmount() - client.funds[int(n.getFundNumber1())].getAmount():
                    currentamount = client.funds[int(n.getFundNumber1())].getAmount()
                    
                    #Takes the amount we can from the inital fund
                    #and adds that transaction to the fund's history
                    client.funds[int(n.getFundNumber1())].withdrawl(n.getAmount())
                    trans = n.getTransactionType() + " " + n.getAccNumber1() + n.getFundNumber1() + " " + str(currentamount) + " " + n.getAccNumber2() + n.getFundNumber2()
                    n.setAmount(n.getAmount() - currentamount) 
                    client.funds[int(n.getFundNumber1())].addHistory(trans)

                    #Takes the rest from the other fund
                    #and adds that transaction to the fund's history
                    client.funds[int(n.getFundNumber1()) + 1].withdrawl(n.getAmount())
                    trans2 = n.getTransactionType() + " " + n.getAccNumber1() + str(int(n.getFundNumber1()) + 1) + " " + str(n.getAmount()) + " " + n.getAccNumber2() + n.getFundNumber2()
                    client.funds[int(n.getFundNumber1()) + 1].addHistory(trans2)

                #Checks for the special case in which we are trying to transfer from the Prime Money Market or Short-Term Bond account
                #and it must be covered by the Money Market and Long-Term Bond account, respectively
                elif n.getAmount() > client.funds[int(n.getFundNumber1())].getAmount() and (int(n.getFundNumber1()) == 1 or int(n.getFundNumber1()) == 3) and client.funds[int(n.getFundNumber1()) - 1].getAmount() >= n.getAmount() - client.funds[int(n.getFundNumber1())].getAmount():
                    currentamount = client.funds[int(n.getFundNumber1())].getAmount()
                    
                    #Takes the amount we can from the inital fund
                    #and adds that transaction to the fund's history
                    client.funds[int(n.getFundNumber1())].withdrawl(n.getAmount())
                    trans = n.getTransactionType() + " " + n.getAccNumber1() + n.getFundNumber1() + " " + str(currentamount) + " " + n.getAccNumber2() + n.getFundNumber2()
                    n.setAmount(n.getAmount() - currentamount) 
                    client.funds[int(n.getFundNumber1())].addHistory(trans)

                    #Takes the rest from the other fund
                    #and adds that transaction to the fund's history
                    client.funds[int(n.getFundNumber1()) + 1].withdrawl(n.getAmount())
                    trans2 = n.getTransactionType() + " " + n.getAccNumber1() + str(int(n.getFundNumber1()) - 1) + " " + str(n.getAmount()) + " " + n.getAccNumber2() + n.getFundNumber2()
                    client.funds[int(n.getFundNumber1()) + 1].addHistory(trans2)
                    
                #Creates an error and adds it to the fund's history if it has insufficient funds
                #to do the transfer
                elif n.getAmount() > client1.funds[int(n.getFundNumber1())].getAmount():
                    error = "ERROR: Fund " + str(n.getFundNumber1()) + " of account number " + str(n.getAccNumber1()) + " has insufficient funds to make this transfer of " + str(n.getAmount()) + " dollars."
                    client1.funds[int(n.getFundNumber1())].addHistory(error)
    
                elif client1 != None and client2 != None:
                    client1.funds[int(n.getFundNumber1())].withdrawl(n.getAmount())
                    client2.funds[int(n.getFundNumber2())].deposit(n.getAmount())
                    client1.funds[int(n.getFundNumber1())].addHistory(n.getTransaction())
                    client2.funds[int(n.getFundNumber2())].addHistory(n.getTransaction())

            #Handles the printing of History
            if n.getTransactionType() == "H":
                client = self.__bank.getClient(n.getAccNumber1())

                if client == None:
                    print("ERROR: Account requested is not in Bank.")

                #loops through each fund in the client
                #prints the fund number, total
                #and history
                if n.getFundNumber1() == "":
                    print("Account Number: " + str(n.getAccNumber1()))
                    print("Client: " + str(client.getName()))
                    
                    i = 0
                    while i < len(client.funds):
                        if client.funds[i].getAmount() == 0 and len(client.funds[i].getHistory()) == 0:
                            j = 0
                        else:
                            print("Fund # " + str(i))
                            print("Total:", str(client.funds[i].getAmount()))
                            client.funds[i].printHistory()
                        i += 1
                        
                #if they only want the history of a specific fund
                #this code executes
                if n.getFundNumber1() != "":
                        print("Client: " + str(client.getName()))
                        print("Account Number: " + str(n.getAccNumber1()))
                        print("Fund #: " + str(n.getFundNumber1()))
                        print("Total: ", str(client.funds[int(n.getFundNumber1())].getAmount()))
                        print(client.funds[int(n.getFundNumber1())].printHistory())
            
                      
            


JollyBanker()
JollyBanker.executeTransactions(JollyBanker())
