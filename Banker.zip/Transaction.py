#Samson Haile
#12/13/2017
#Transaction

#This class simulates the Transaction as a part of the JollyBanker program
class Transaction:

    #Constructor. Since where the data lies in the transaction is specific to the transaction
    #we set all of them besides the amount and transaction type to empty
    def __init__(self, t):
        self.__transaction = t
        self.__transtype = t[0:1]
        self.__name = ""
        self.__accnumber = ""
        self.__fundnum = ""
        self.__amount = 0
        self.__fundnum2 = ""
        self.__accnumber2 = ""

        #parses the data from the transaction
        #if the transaction is to open an account
        if self.__transtype == "O":
            self.__name = t.split()[2] + " " + t.split()[1]
            self.__accnumber = t.split()[3]
        
        #parses the data from the transaction
        #if the transaction is to deposit 
        if self.__transtype == "D":
            self.__accnumber = t[2:6]
            self.__fundnum = t[6]
            self.__amount = t.split()[2]

        #parses the data from the transaction
        #if the transaction is to withdraw
        if self.__transtype == "W":
            self.__accnumber = t[2:6]
            self.__fundnum = t[6]
            self.__amount = t.split()[2]

        #parses the data from the transaction
        #if the transaction is to transfer between two funds
        if self.__transtype == "T":
            self.__accnumber = t[2:6]
            self.__fundnum = t[6]
            self.__amount = t.split()[2]
            self.__accnumber2 = t.split()[3][0:4]
            self.__fundnum2 = t.split()[3][4]

        #parses the data from the transaction
        #if the transaction is to get the history of a fund
        if self.__transtype == "H":
            self.__accnumber = t.split()[1][0:4]
            if len(t.split()[1]) == 5:
                self.__fundnum = t.split()[1][4]

    #sets the transaction type (Open, Withdraw, Deposit, Transfer, History)
    def setTransactionType(self, tt):
        self.__transtype = tt

    #returns the entire transaction, as read in from the queue
    def getTransaction(self):
        return self.__transaction

    #gets the transaction type (O, W, D, T, H)
    def getTransactionType(self):
        return self.__transtype

    #gets the name of the account (only relevant for opening an account)
    def getName(self):
        return self.__name

    #sets the name on an account
    def setName(self, name):
        self.__name = name

    #gets the account number of the first account (or only account if there is only one)
    def getAccNumber1(self):
        return self.__accnumber

    #gets the first fund number (or only fund number if there is only one)
    def getFundNumber1(self):
        return self.__fundnum

    #gets the amount on the transaciton
    def getAmount(self):
        return int(self.__amount)

    #sets the amount on the transaction
    def setAmount(self, amount):
        self.__amount = amount

    #gets the second account number (only relevant for transfers)
    def getAccNumber2(self):
        return self.__accnumber2

    #gets the second fund number (only relevant for transfers)
    def getFundNumber2(self):
        return self.__fundnum2



